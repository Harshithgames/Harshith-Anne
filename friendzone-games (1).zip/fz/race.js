const cv=document.getElementById('c'),ctx=cv.getContext('2d'),W=900,H=560,CX=W/2,CY=H/2,RX=360,RY=210,TW=95,LAPS=3;
const $=id=>document.getElementById(id);
let mode=null,peer=null,conn=null,isHost=true,state='menu',wins=[0,0],winner=-1;
const keys={},remote={};
const K=[{u:'w',d:'s',l:'a',r:'d'},{u:'ArrowUp',d:'ArrowDown',l:'ArrowLeft',r:'ArrowRight'}];
addEventListener('keydown',e=>{keys[e.key.length==1?e.key.toLowerCase():e.key]=1;if(e.key.startsWith('Arrow'))e.preventDefault()});
addEventListener('keyup',e=>{keys[e.key.length==1?e.key.toLowerCase():e.key]=0});
document.querySelectorAll('.pad button').forEach(b=>{const k=b.dataset.k;
 const on=e=>{e.preventDefault();keys[k]=1;b.classList.add('on')},off=e=>{e.preventDefault();keys[k]=0;b.classList.remove('on')};
 b.addEventListener('pointerdown',on);b.addEventListener('pointerup',off);b.addEventListener('pointerleave',off);b.addEventListener('pointercancel',off)});
let cars=[];
function reset(){cars=[0,1].map(i=>({x:CX-10,y:CY+RY+(i?-22:22),a:Math.PI,v:0,lap:0,prog:0,last:Math.PI/2}));winner=-1;updHud()}
function myInput(i){// in online each side uses either keyset
 const k=K[i],alt=K[1-i],g=x=>keys[k[x]]||(mode=='online'&&keys[alt[x]]);return{u:g('u'),d:g('d'),l:g('l'),r:g('r')}}
function inputFor(i){if(mode=='local')return myInput(i);if(i==0)return myInput(0);return remote}
function onTrack(x,y){const d=Math.hypot((x-CX)/RX,(y-CY)/RY);return Math.abs(d-1)*Math.min(RX,RY)<TW/2}
function step(dt){cars.forEach((c,i)=>{const n=inputFor(i)||{};
 if(n.u)c.v+=420*dt;if(n.d)c.v-=300*dt;c.v*=onTrack(c.x,c.y)?0.985:0.94;c.v=Math.max(-120,Math.min(380,c.v));
 const t=Math.min(1,Math.abs(c.v)/150)*Math.sign(c.v);if(n.l)c.a-=2.8*dt*t;if(n.r)c.a+=2.8*dt*t;
 c.x+=Math.cos(c.a)*c.v*dt;c.y+=Math.sin(c.a)*c.v*dt;c.x=Math.max(10,Math.min(W-10,c.x));c.y=Math.max(10,Math.min(H-10,c.y));
 const ang=Math.atan2((c.y-CY)/RY,(c.x-CX)/RX);let d=ang-c.last;if(d>Math.PI)d-=2*Math.PI;if(d<-Math.PI)d+=2*Math.PI;c.last=ang;c.prog+=d;
 if(c.prog>=2*Math.PI){c.prog-=2*Math.PI;c.lap++;updHud();if(c.lap>=LAPS&&winner<0)finish(i)}});
 const[a,b]=cars,dx=b.x-a.x,dy=b.y-a.y,dd=Math.hypot(dx,dy);if(dd<20&&dd>0){const p=(20-dd)/2;a.x-=dx/dd*p;a.y-=dy/dd*p;b.x+=dx/dd*p;b.y+=dy/dd*p;a.v*=.9;b.v*=.9}}
function finish(i){winner=i;wins[i]++;state='over';showWin();send({t:'win',w:i,wins})}
function showWin(){$('winTxt').textContent=`PLAYER ${winner+1} WINS!`;$('winTxt').style.color=winner?'#22f3ff':'#ff2bd6';$('win').classList.remove('hide');updHud()}
function updHud(){$('l1').textContent=cars[0]?.lap||0;$('l2').textContent=cars[1]?.lap||0;$('w1').textContent=wins[0];$('w2').textContent=wins[1]}
function countdown(){reset();state='cd';$('win').classList.add('hide');$('menu').classList.add('hide');$('cdBox').classList.remove('hide');let n=3;$('cd').textContent=n;
 const iv=setInterval(()=>{n--;if(n>0)$('cd').textContent=n;else if(n==0)$('cd').textContent='GO!';else{clearInterval(iv);$('cdBox').classList.add('hide');state='race'}},800)}
function start(){countdown();send({t:'start'})}
function car(c,col){ctx.save();ctx.translate(c.x,c.y);ctx.rotate(c.a);ctx.shadowColor=col;ctx.shadowBlur=18;ctx.fillStyle=col;ctx.fillRect(-14,-8,28,16);ctx.fillStyle='#fff';ctx.fillRect(6,-6,5,12);ctx.restore()}
function draw(){ctx.clearRect(0,0,W,H);ctx.lineWidth=TW;ctx.strokeStyle='#1d1446';ctx.beginPath();ctx.ellipse(CX,CY,RX,RY,0,0,7);ctx.stroke();
 ctx.lineWidth=3;ctx.shadowBlur=14;[['#ff2bd6',TW/2],['#22f3ff',-TW/2]].forEach(([c,o])=>{ctx.strokeStyle=c;ctx.shadowColor=c;ctx.beginPath();ctx.ellipse(CX,CY,RX+o,RY+o,0,0,7);ctx.stroke()});
 ctx.shadowBlur=0;ctx.setLineDash([16,14]);ctx.strokeStyle='#ffffff30';ctx.beginPath();ctx.ellipse(CX,CY,RX,RY,0,0,7);ctx.stroke();ctx.setLineDash([]);
 ctx.fillStyle='#b6ff3b';ctx.shadowColor='#b6ff3b';ctx.shadowBlur=12;ctx.fillRect(CX-3,CY+RY-TW/2,6,TW);ctx.shadowBlur=0;
 if(cars.length){car(cars[0],'#ff2bd6');car(cars[1],'#22f3ff')}}
function send(m){if(conn&&conn.open)conn.send(m)}
let lt=performance.now(),tick=0;
function loop(t){const dt=Math.min(.033,(t-lt)/1000);lt=t;
 if(state=='race'&&isHost)step(dt);
 if(mode=='online'){if(isHost){if(++tick%2==0)send({t:'s',cars:cars.map(c=>[c.x,c.y,c.a,c.lap])})}else send({t:'i',n:myInput(1)})}
 draw();requestAnimationFrame(loop)}
function onMsg(m){if(m.t=='i')Object.assign(remote,m.n);else if(m.t=='s'){m.cars.forEach((a,i)=>{if(cars[i]){[cars[i].x,cars[i].y,cars[i].a]=a;if(cars[i].lap!=a[3]){cars[i].lap=a[3];updHud()}}})}
 else if(m.t=='start')countdown();else if(m.t=='win'){winner=m.w;wins=m.wins;state='over';showWin()}else if(m.t=='again'&&isHost)start()}
$('local').onclick=()=>{mode='local';isHost=true;start()};
$('create').onclick=()=>{if(!window.Peer)return $('status').textContent='Online unavailable';const code=Math.random().toString(36).slice(2,7).toUpperCase();
 peer=new Peer('fzgames-'+code);$('status').textContent='Connecting...';peer.on('open',()=>$('status').innerHTML=`Room code: <b style="color:#b6ff3b;font-size:1.4rem">${code}</b><br>Share it with your friend!`);
 peer.on('connection',c=>{conn=c;mode='online';isHost=true;c.on('data',onMsg);c.on('open',()=>start())});peer.on('error',e=>$('status').textContent='Error: '+e.type)};
$('join').onclick=()=>{const code=$('code').value.trim().toUpperCase();if(!code||!window.Peer)return;peer=new Peer();$('status').textContent='Joining...';
 peer.on('open',()=>{conn=peer.connect('fzgames-'+code);mode='online';isHost=false;conn.on('data',onMsg);conn.on('open',()=>$('status').textContent='Connected! Get ready (you are P2, cyan)')});peer.on('error',e=>$('status').textContent='Error: '+e.type)};
const again=()=>{if(!mode)return;if(isHost)start();else send({t:'again'})};
$('again').onclick=again;$('restart').onclick=again;
$('save').onclick=()=>{const n=$('name').value.trim();if(!n)return;const lb=JSON.parse(localStorage.getItem('fz_lb')||'{}');lb[n]=(lb[n]||0)+1;localStorage.setItem('fz_lb',JSON.stringify(lb));$('save').textContent='Saved ✓';$('save').disabled=true;setTimeout(()=>{$('save').textContent='Save to Leaderboard';$('save').disabled=false},1500)};
reset();requestAnimationFrame(loop);
